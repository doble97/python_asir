user = input('Usuario: ')
password = input('Password: ')
respuesta = 'Login correcto' if user=='root' and password=='toor' else 'Login incorrecto'
print(respuesta)