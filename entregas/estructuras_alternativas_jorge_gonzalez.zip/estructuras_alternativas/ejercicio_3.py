num = int(input('Escribe un número: '))
if num%2==0:
    print('Es par')
else:
    print('Es impar')