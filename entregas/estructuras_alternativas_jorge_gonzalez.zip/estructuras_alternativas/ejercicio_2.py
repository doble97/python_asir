num = int(input('Número: '))
if num > 0:
    print('Positivo')
elif num<0:
    print('Negativo')
else:
    print('El número es 0')