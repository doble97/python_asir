num1 = int(input('Escribe un número: '))
num2 = int(input('Escribe un número: '))
if num1>num2:
    print(num1, 'es mayor que', num2)
elif num2>num1:
    print(num2, 'es mayor que', num1)
else:
    print('Los dos numeros son iguales')
