num1=int(input('Número: '))
num2=int(input('Número: '))
if num2!=0:
    print('División',num1/num2)
else:
    print('No se puede dividir entre 0')